<?php

echo "PayU constansts";

?>
